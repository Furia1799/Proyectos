<?php
session_start();

include('conexionOracle.php');

$bandera = false;

include('probar_consultas.php');

?>

<html>
<head>
    <title>Registro Nuevo</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>

        function validarCURP()
        {
            valor = document.getElementById("usuario").value;
            if(valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                alert('Falta Llenar Usuario');
                return false;
            }else{ return true;}
        }

        function validarPassword()
        {
            valor = document.getElementById("password").value;
            if(valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                alert('Falta Llenar Password');
                return false;
            }else{
                valor2 = document.getElementById("con_password").value;
                if (valor == valor2)
                {
                    return true;
                }else{ alert('Las contraselas no coinciden'); return false;}

            }
        }
        /*
        function validarTipoUsuario()
        {
            indice = document.getElementById("tipo_usuario").value;

            if(indice == null || indice==0) {
                alert('Seleccione tipo de usuario');
                alert(indice);
                return false;
            }else{ return true;}

            && validarTipoUsuario()
        }*/

        function validar()
        {
            if (validarCURP() && validarPassword() )
            {
                document.registro.submit();
            }
        }

    </script>

    <style>

        *{
            margin: 0px;
            padding: 0px;
        }

        body{
            background: url(images/WALLPAPER.jpg);
            background-size: 100vw 100vh;
            background-attachment: fixed;

        }

        form{
            font-family: 'Poppins', sans-serif;
			text-align: center;
			background: #f0fdff;
			width: 400px;
			margin:80px auto;
            padding: 10px;
        }
        form h1{
            font-family: 'Poppins', sans-serif;
				text-align: center;
				color: #23527c;
				font-weight: normal;
				font-size: 40pt;
				margin: 30px 0px;
        }
        form input{
           /* width: 200px;
            height: 25px;
            margin: 10px 30px;*/
        }

        a{
         /*   color: #000;
            padding: 5px 5px;
            font-size: 18px;*/
        }
        a:active{
        /*    background: #2EFE64;*/
        }

        nav.menu1{
            /*width: 890px;
            height: 50px;
            margin: 0;
            padding: 0;*/
        }
        nav.menu1 li{
         /*   display: block;
            float: left;
            padding: 0 10px;*/
        }
    </style>

</head>
<body>

<section>
    <div class="container">
        
        <div class="row">
            
            <div class="col-lg-12">
                <form action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" >
                <input type="hidden" name="hidden" value="1"/>
                <h1>Registrate</h1>
                <div>
                    <div class="text-center">
                        <label for="">CURP:</label>
                        <input class="form-control" id="CURP" type="text" name="CURP"
                               minlength="10" maxlength="20" required pattern="[A-Za-z0-9]{10,20}">
                    </div>
                    <div class="text-center">
                        <label for="">Nombre:</label>
                        <input class="form-control" id="nombre" type="text" name="nombre"
                               minlength="3" maxlength="40" required pattern="[A-Z a-z ]{3,40}">
                    </div>
                    <div class="text-center">
                        <label for="">Apellidos:</label>
                        <input class="form-control" id="apellidos" type="text" name="apellidos"
                               minlength="3" maxlength="50" required pattern="[A-Z a-z ]{3,50}">
                    </div>
                    <div class="text-center">
                        <label for="">Fecha de Nacimiento:</label>
                        <input class="form-control" id="fecha_nacimiento" type="date" name="fecha_nacimiento" required pattern="[A-Za-z0-9]{1,15}">
                    </div>
                    <div class="text-center">
                        <label for="">Codigo Postal:</label>
                        <input class="form-control" id="codigo_postal" type="number" name="codigo_postal" required pattern="[0-9]{1,10}">
                    </div>
                    <div class="text-center">
                        <label for="">Estado:</label>
                        <input class="form-control" id="estado" type="text" name="estado"
                               minlength="2" maxlength="40" required pattern="[A-Za-z ]{2,40}">
                    </div>
                    <div class="text-center">
                        <label for="">Localidad:</label>
                        <input class="form-control" id="localidad" type="text" name="localidad"
                               minlength="2" maxlength="40" required pattern="[A-Za-z ]{2,40}">
                    </div>
                    <div class="text-center">
                        <label for="">Domicilio:</label>
                        <input class="form-control" id="domicilio" type="text" name="domicilio"
                               minlength="5" maxlength="40" required pattern="[A-Za-z0-9# ]{5,40}">
                    </div>
                    <div class="text-center">
                        <label for="">Email:</label>
                        <input class="form-control" id="email" type="email" name="email" required pattern="[A-Za-z0-9@.]{1,30}">
                    </div>
                    <div class="text-center">
                        <label for="">Password:</label>
                        <input class="form-control" id="password" type="password" name="password"
                               minlength="5" maxlength="30" required pattern="[A-Za-z0-9]{5,30}">
                    </div>
                    <div class="text-center">
                        <label for="">Confirmar Password:</label>
                        <input class="form-control" id="con_password" type="password" name="con_password"
                               minlength="5" maxlength="30" required pattern="[A-Za-z0-9]{5,30}">
                    </div>

                </div>
                <br>
                <div class="text-center">
                    <input class="form-control btn btn-success"type="submit" value="Registrar" name="btn_guardar" onclick="validar();">
                </div>
                </form>

                <?php if($bandera){ ?>
                    <?php //echo '<script type="text/javascript">alert("Agregado correctamente");</script>';
                    //header("location: index.php");
                    ?>
                <?php   } else{ ?>
                    <br />
                    <div style="font-size:16px; color:#cc0000;"><?php echo isset($error) ? utf8_decode($error) : '' ; ?></div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>
</body>
</html>
<?php

?>